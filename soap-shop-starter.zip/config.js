// ใส่ URL ที่ได้จากการ Deploy Google Apps Script เป็น Web App
window.SHOP_CONFIG = {
  API_URL: "ใส่_URL_GOOGLE_APPS_SCRIPT_WEB_APP_ที่นี่"
};