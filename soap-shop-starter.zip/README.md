# SOAP&HOME — Landing Page + Order Management

โปรเจกต์ตัวอย่างร้านชามสบู่ มีสินค้า 2 SKUs, ฟอร์มสั่งซื้อ, Google Sheets API, หน้าจัดการออเดอร์ และพิมพ์ใบปะหน้าพัสดุ

## ไฟล์ในโปรเจกต์
- `index.html`, `styles.css`, `app.js` — เว็บไซต์
- `config.js` — URL ของ Google Apps Script Web App
- `apps-script/Code.gs` — API เชื่อม Google Sheets
- `public/images/` — ภาพตัวอย่างสินค้า SVG (เปลี่ยนเป็นภาพถ่ายสินค้าได้)

## ตั้งค่า Google Sheets
1. สร้าง Google Sheet ใหม่
2. ไปที่ Extensions → Apps Script
3. วางโค้ดจาก `apps-script/Code.gs`
4. เลือกฟังก์ชัน `setup` แล้วกด Run เพื่อสร้างหัวตารางและอนุญาตสิทธิ์
5. ไปที่ Project Settings → Script Properties เพิ่ม `ADMIN_KEY` เป็นรหัสยาวที่คาดเดายาก
6. Deploy → New deployment → Web app
7. Execute as: Me; Who has access: Anyone (จำเป็นสำหรับหน้าเว็บสาธารณะ) แล้ว Deploy
8. คัดลอก Web app URL ไปใส่ใน `config.js` ที่ `API_URL`

## Deploy บน GitHub และ Vercel
1. สร้าง GitHub repository ใหม่และอัปโหลดไฟล์ทั้งหมดในโฟลเดอร์นี้
2. เข้า Vercel → Add New → Project → Import Git Repository
3. เลือก repository นี้; Framework Preset: Other; Build Command: เว้นว่าง; Output Directory: `.` 
4. กด Deploy แล้วใช้โดเมน `.vercel.app` ที่ได้รับ

## ทดสอบ
- สั่งซื้อสินค้าอย่างน้อย 1 รายการจากหน้าเว็บ
- เปิด Google Sheet ตรวจสอบแถวคำสั่งซื้อ
- ไปที่ส่วนจัดการคำสั่งซื้อ ใส่ `ADMIN_KEY` แล้วโหลดรายการ
- กด “แพ็กแล้ว”, กรอกเลขพัสดุ และกด “บันทึกเลขพัสดุ/จัดส่ง”
- กด “พิมพ์ใบปะหน้า” แล้วพิมพ์หรือบันทึกเป็น PDF

## ก่อนใช้งานจริง
- เปลี่ยนชื่อร้าน ข้อมูลผู้ส่ง รูปภาพสินค้า ราคา และรายละเอียดสินค้า
- เพิ่มการตรวจสอบความถูกต้องของเบอร์โทร/ที่อยู่ และนโยบายข้อมูลส่วนบุคคล
- ตัวอย่างนี้เป็นงานสาธิต ไม่ใช่ระบบชำระเงินออนไลน์ และไม่มีการเชื่อมผู้ให้บริการขนส่งโดยตรง
- สำหรับใช้งานจริงควรจำกัดสิทธิ์ API, เพิ่มการป้องกันสแปม/คำสั่งซื้อปลอม และไม่ใช้ข้อมูลลูกค้าจริงในการสาธิตชั้นเรียน
